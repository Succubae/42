/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:22:05 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 14:23:08 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "graph.h"

t_node		*free_node(t_node *n)
{
	t_link	*tmp;

	free(n->name);
	while (n->link)
	{
		tmp = n->link->next;
		free(n->link);
		n->link = tmp;
	}
	free(n);
	return (NULL);
}

t_tree		*ft_free(t_tree *t)
{
	t_list	*tmp;

	while (t->tree)
	{
		tmp = t->tree->next;
		free_node(t->tree->data);
		free(t->tree);
		t->tree = tmp;
	}
	free(t);
	return (NULL);
}

int		free_list(t_list *lst)
{
	t_list	*tmp;

	while (lst)
	{
		tmp = lst->next;
		free(lst);
		lst = tmp;
	}
	return (0);
}
