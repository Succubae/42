/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:28:44 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 14:31:11 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "graph.h"

t_list	*llconvert(void *p)
{
	return (p);
}

t_list	*new_list(void *data, t_list *next)
{
	t_list	*new;

	new = gr_malloc(sizeof(*new));
	new->data = data;
	new->next = next;
	return (new);
}

t_list	*append_list(t_list *lst, void *new)
{
	if (lst == NULL)
		return (new_list(new, NULL));
	lst->next = append_list(lst->next, new);
	return (lst);
}

int		size_list(t_list *lst)
{
	unsigned int  i;

	i = 0;
	while (lst)
	{
		i++;
		lst = lst->next;
	}
	return (i);
}

void	setflag_traveled(t_node *n)
{
	n->state |= FLAGS_TRAVELED;
}

void	setflag_untraveled(t_node *n)
{
	n->state &= ~FLAGS_TRAVELED;
}

void	setflag_done(t_node *n)
{
	n->state |= FLAGS_DONE;
}
