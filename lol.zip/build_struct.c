/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   build_struct.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:06:24 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 14:16:40 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "graph.h"

t_node		*init_node(char *name, int flag)
{
	t_node	*new;

	new = (t_node*)malloc(sizeof(t_node));
	new->name = name;
	new->state = flag;
	new->n = 0;
	new->link = NULL;
	return (new);
}

t_link		*init_link(t_node *node, t_link *next)
{
	t_link	*new;

	new = (t_link*)malloc(sizeof(t_link));
	new->data = node;
	new->next = next;
	return (new);
}

t_tree		*init_tree(void)
{
	t_tree	*new;

	new = (t_tree*)malloc(sizeof(t_tree));
	new->tree = NULL;
	new->nnode = 0;
	new->nlink = 0;
	return (new);
}
