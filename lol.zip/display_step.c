/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_step.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:18:36 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 16:43:53 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "graph.h"
#include "lemin.h"

void		disp_move(t_node *a)
{
	static int	space = 0;

	if (!a)
	{
		if (space)
	write(1, "\n", 1);
		space = 0;
	}
	else
	{
		if (space)
			write(1, " ", 1);
		else
			space = 1;
		write(1, "P", 1);
		ft_putnbr(a->n);
		write(1, "-", 1);
		write(1, a->name, my_strlen(a->name));
	}
}

int		update_way(t_list *lst, int *npassed, int *antnbr, int totalants)
{
	if (!lst || !lst->next)
		return (0);
	update_way(lst->next, npassed, antnbr, totalants);
	if (NODE(lst->data)->state & FLAGS_ANT)
	{
		NODE(lst->next->data)->state |= FLAGS_ANT;
		NODE(lst->next->data)->n = NODE(lst->data)->n;
		NODE(lst->data)->state &= ~FLAGS_ANT;
		disp_move(lst->next->data);
		if (NODE(lst->next->data)->state & FLAGS_END)
			(*npassed)++;
	}
	else if ((NODE(lst->data)->state & FLAGS_START) && (*antnbr > 0))
	{
		NODE(lst->next->data)->state |= FLAGS_ANT;
		NODE(lst->next->data)->n = totalants - (*antnbr)-- + 1;
		disp_move(lst->next->data);
		if (NODE(lst->next->data)->state & FLAGS_END)
			(*npassed)++;
	}
	return (0);
}
