/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:32:43 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 16:40:50 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "graph.h"
#include "lemin.h"

int		main(void)
{
	t_data	data;
	t_list	*tmp;

	data.t = init_tree();
	read_infos(&data);
	data.sorted = NULL;
	if (!(data.start = find_node(data.t->tree, FLAGS_START)))
	{
		gr_error(GR_E_NOSTART);
		ft_free(data.t);
		return (1);
	}
	apply_on_nodes(data.t->tree, setflag_untraveled);
	while ((tmp = gr_find_shortest_way(data.t, data.start)) && (size_list(tmp) > 2))
	{
		data.sorted = append_list(data.sorted, tmp);
		apply_on_nodes(data.t->tree, setflag_untraveled);
		apply_on_nodes(tmp, setflag_done);
	}
	lem_in(&data, tmp);
	free_sorted(data.sorted);
	ft_free(data.t);
	return (0);
}

void		lem_in(t_data *data, t_list *tmp)
{
	int		i;

	if (!data->sorted && (size_list(tmp) <= 2))
	{
		i = 0;
		while (++i <= data->antnbr)
		{
			NODE(tmp->next->data)->n = i;
			disp_move(tmp->next->data);
		}
		disp_move(NULL);
	}
	else
		lem_in_proceed(data);
}

void		lem_in_proceed(t_data *data)
{
	int		npassed;
	int		antnbr;
	t_list	*tmp;

	if (data->sorted)
	{
		npassed = 0;
		antnbr = data->antnbr;
		while ((npassed < data->antnbr) && data->sorted)
		{
			tmp = data->sorted;
			while (tmp)
			{
				update_way(tmp->data, &npassed, &antnbr, data->antnbr);
				tmp = tmp->next;
			}
			disp_move(NULL);
		}
	}
	else
		gr_error(GR_E_NOEND);
}
