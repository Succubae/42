/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:02:09 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 14:02:51 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdarg.h>
#include "graph.h"

int		gr_error(const char *fmt, ...)
{
  va_list	lst;
  char		*s;

  va_start(lst, fmt);
  while (*fmt)
    {
      if ((*fmt == '%') && (fmt[1] == 's'))
	{
	  s = va_arg(lst, char *);
	  write(2, s, my_strlen(s));
	  fmt++;
	}
      else
	write(2, fmt, 1);
      fmt++;
    }
  va_end(lst);
  return (0);
}
