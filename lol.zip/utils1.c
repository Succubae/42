/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgary <rgary@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/18 14:24:02 by rgary             #+#    #+#             */
/*   Updated: 2014/02/18 14:27:11 by rgary            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "graph.h"
#include "lemin.h"

int		ft_getnbr(char *s)
{
	int		res;

	res = 0;
	while ((*s >= '0') && (*s <= '9'))
		res = (res * 10) + *s++ - '0';
	return (res);
}

void	*gr_malloc(unsigned int len)
{
	void      *p;

	if (!(p = malloc(len)))
	{
		gr_error(GR_E_MALLOC);
		exit(1);
	}
	return (p);
}

int		apply_on_nodes(t_list *l, void (*fct)(t_node *))
{
	if (!l)
		return (0);
	fct(l->data);
	return (apply_on_nodes(l->next, fct));
}

t_node	*find_node(t_list *lst, unsigned int flag)
{
	while (lst)
	{
		if (NODE(lst->data)->state & flag)
			return (lst->data);
		lst = lst->next;
	}
	return (NULL);
}
